<?php
function handle_callback_query_kirim($botdata){
    if(!empty($botdata["data"]) 
    and f("str_is_diawali")($botdata["data"], "kirim_")
    and !empty($botdata["message"]["reply_to_message"])
    ){
        $datakirim = $botdata["message"]["reply_to_message"];
        $jenis = str_replace("kirim_","",$botdata["data"]);
        if($jenis == "text"){
            return f("handle_message_send_text")($datakirim);
        }
        else{
            $explode = explode("_",$jenis);
            if(!empty($explode[1])){
                $jenis = $explode[0];
                $fileid = $explode[1];
                if(empty($jenis) or empty($fileid)){
                    return false;
                }
                else{
                    return f("handle_message_send_media")($datakirim, $jenis, $fileid);
                }
            }
            else{
                return false;
            }
        }
    }
}